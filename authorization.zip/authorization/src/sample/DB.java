package sample;

import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

public class DB {

    private final String HOST = "172.16.225.104";
    private final String PORT = "3306";
    private final String DB_NAME = "user22";


    private Connection dbConn = null;

    //метод для подключения к бд
    private Connection getDbConnection() throws ClassNotFoundException, SQLException {
        Properties properties = new Properties();

        properties.setProperty("user","user22");
        properties.setProperty("password","37354");
        properties.setProperty("useUnicode","true");
        properties.setProperty("characterEncoding","utf8");

        String connStr = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DB_NAME;
        Class.forName("com.mysql.cj.jdbc.Driver");

        dbConn = DriverManager.getConnection(connStr, properties);
        return dbConn;
    }

    //метод для получения данных из бд
    public boolean validate(String login, String password) throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM registration WHERE email_id = "+login+" and password = "+password+"";

        try(Statement statement = getDbConnection().createStatement();
        ResultSet res = statement.executeQuery(sql);

        if (statement.next()) {
            return true;
        }

    }

}


